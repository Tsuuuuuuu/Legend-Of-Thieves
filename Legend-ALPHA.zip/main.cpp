/* 
Skyy Civil
*/
   
//   LEGEND \\

#include <iostream>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <random>
#include <vector>
#include <unistd.h>

using namespace std;

	/*
	Global variables
	*/
	int XP=0;
	int Lvl=0;
	int LvlCount;
	int coins = 500;
	

/*
Declaring functions
*/
void Menu();
void Login();
void LevelStart();
void GameMenu();
void LvlUp();
int LvlWin();
int LvlUpReq();
int XpClear();
void Shop();
int AddCoins();
void ClearScreen();
/* No files, struct instead.

structing monsters and hero and damage
*/
struct Monster
{
	int monsterCount;
	string monsterType;
	int monsterHealth;
	
};

// Hero
struct Hero{

	int health;
	int mana;
};

// Create shop choices




struct Attacks{
	string attack1;
	string attack2;
	string attack3;
	string attack4;
	string attack5;
	string attack6;
	string attack7;
	// Add melee attacks (attakcs 5, 6, 7) \\
	Now I can put text here that wont effect the code.
	int damageAttack1;
	int damageAttack2;
	int damageAttack3;
	int damageAttack4;
	int damageAttack5;
	int damageAttack6;
	int damageAttack7;
	// Mana used per attack, attacks 5, 6, 7 are melee and do not use mana
	int manaAttack1;
	int manaAttack2;
	int manaAttack3;
	int manaAttack4;
	int manaAttack5=0;
	int manaAttack6=0;
	int manaAttack7=0;
};

struct Inventory{
	// Items \\
	Owned

	string purchasedItem1;
	string purchasedItem2;
	string purchesedItem3;
	string PowerUp;
	// Effect \\
	Effect for each item
	int HP1;
	int HP2;
	int HP3;
	int HP4;
	// How many of each item
	int item1cnt;
	int item2cnt;
	int item3cnt;
};
struct Shop{
		string item1;
	string item2;
	string item3;
	int item1Price;
	int item2Price;
	int item3Price;
};

// Clear screen, pretty pathetic eh?
  void ClearScreen()
    {
    int n;
    for (n = 0; n < 10; n++)
      printf( "\n\n\n\n\n\n\n\n\n\n" );
    }





/*
Requirements for leveling Leveling up
*/

int LvlUpReq(int XP, int Lvl){
	int LvlUpReq;
	LvlUpReq = 200;

	if(XP >= LvlUpReq){
		LvlUpReq++;
	}

	return (LvlUpReq);
}



int LvlWin(int XP){
	XP = XP + 100;
	coins += 100;
	return (XP);
}

int LvlUp(int XP, int Lvl){
    Lvl += XP / LvlUpReq(XP, Lvl);
		XP = 0;
    return Lvl;
		
}
/*
		Global constructors
*/

		struct Hero player;
	struct Attacks playerAttacks;
	struct Attacks monsterAttacks;
	struct Inventory playerInv;
	struct Monster levelMonster;
	struct Shop shopChoice;

/*
	Shoppe
*/

void Shop(int coins){
	int ui = 1;
	int choice;
	shopChoice.item1 = "Small health potion";
	shopChoice.item1Price = 100;
	shopChoice.item2 = "Medium potion";
	shopChoice.item2Price = 300;
	shopChoice.item3 = "Large potion";
	shopChoice.item3Price = 500;
	cout << 
"░██████╗██╗░░██╗░█████╗░██████╗░\n"
"██╔════╝██║░░██║██╔══██╗██╔══██╗\n"
"╚█████╗░███████║██║░░██║██████╔╝\n"
"░╚═══██╗██╔══██║██║░░██║██╔═══╝░\n"
"██████╔╝██║░░██║╚█████╔╝██║░░░░░\n"
"╚═════╝░╚═╝░░╚═╝░╚════╝░╚═╝░░░░░\n\n\n";
while(ui == 1){
cout << "(1) " << shopChoice.item1 << endl;
cout <<  "Price: " << shopChoice.item1Price << endl;
cout << "(2) "<< shopChoice.item2 << endl;
cout << "Price: " << shopChoice.item2Price<<endl;
cout <<"(3) "<< shopChoice.item3<<endl;
cout << "Price: " << shopChoice.item3Price <<endl;
cout << "(4) Back to game menu\n";
cin >> choice;

if (choice == 1){
	if (coins >= shopChoice.item1Price){
		playerInv.purchasedItem1 = shopChoice.item1;
		playerInv.item1cnt += 1;
		coins -= shopChoice.item1Price;
		cout << "Purchase Complete\n";
		cout << "(1) " << shopChoice.item1 << endl;
cout <<  "Price: " << shopChoice.item1Price << endl;
cout << "(2) "<< shopChoice.item2 << endl;
cout << "Price: " << shopChoice.item2Price<<endl;
cout <<"(3) "<< shopChoice.item3<<endl;
cout << "Price: " << shopChoice.item3Price <<endl;
cout << "(4) Back to game menu\n";
	}
	if (coins < shopChoice.item1Price){
		cout << "Try again\n > ";
	}

}

if (choice == 2){
	if (coins >= shopChoice.item2Price){
		playerInv.purchasedItem1 = shopChoice.item2;
		playerInv.item2cnt += 1;
		coins -= shopChoice.item2Price;
	cout << "Purchase Complete\n";
	cout << "(1) " << shopChoice.item1 << endl;
cout <<  "Price: " << shopChoice.item1Price << endl;
cout << "(2) "<< shopChoice.item2 << endl;
cout << "Price: " << shopChoice.item2Price<<endl;
cout <<"(3) "<< shopChoice.item3<<endl;
cout << "Price: " << shopChoice.item3Price <<endl;
cout << "(4) Back to game menu\n";
	}
	if (coins < shopChoice.item2Price){
		cout << "Try again\n > ";
	}

}
if (choice == 3){
	if (coins >= shopChoice.item3Price){
		playerInv.purchasedItem1 = shopChoice.item3;
		playerInv.item3cnt += 1;
		coins -= shopChoice.item3Price;
		cout << "Purchase Complete!\n";
		cout << "(1) " << shopChoice.item1 << endl;
cout <<  "Price: " << shopChoice.item1Price << endl;
cout << "(2) "<< shopChoice.item2 << endl;
cout << "Price: " << shopChoice.item2Price<<endl;
cout <<"(3) "<< shopChoice.item3<<endl;
cout << "Price: " << shopChoice.item3Price <<endl;
cout << "(4) Back to game menu\n";
	}
if (coins < shopChoice.item3Price){
		cout << "Try again\n > ";
	}
}
if (choice == 4){
	GameMenu();
}

}
}

/*
		The actual level starts here
*/


void LevelStart(int XP, int Lvl){
	
	int playerAttack;

	int PwrUpCnt = 1;

	// Inventory
	
	playerInv.PowerUp = "POWER UP!";
	playerInv.HP1 = 15;
	playerInv.HP2 = 30;
	playerInv.HP3 = 40;
	playerInv.HP4=100;


	// Player attacks and stats
	
	player.health = 150;
	player.mana = 150;
	playerAttacks.attack1 = "FireBall";
	playerAttacks.attack2 = "Fire Slash";
	playerAttacks.attack3 = "Fire Barrage";
	playerAttacks.attack4 = "Blue Flame Bomb";
 playerAttacks.attack5 = "Basic slash";
 playerAttacks.attack6 = "Spin slash";
 playerAttacks.attack7="Slicing combo";
	playerAttacks.damageAttack1 = 10;
	playerAttacks.damageAttack2 = 15;
	playerAttacks.damageAttack3 = 20;
	playerAttacks.damageAttack4 = 40;
	playerAttacks.damageAttack5 = 5;
	playerAttacks.damageAttack6=10;
	playerAttacks.damageAttack7=15;
	// Mana
	playerAttacks.manaAttack1 = 10;
	playerAttacks.manaAttack2 = 15;
	playerAttacks.manaAttack3 = 25;
	playerAttacks.manaAttack4 = 60;
	playerAttacks.manaAttack5 = 0;
	playerAttacks.manaAttack6=0;
	playerAttacks.manaAttack7=0;
	// Monster attacks and stats
	
	levelMonster.monsterCount = 1;
	levelMonster.monsterType = "Phynxis";


	string monsterAttack[3] = {"Bash", "Spin Attack", "Heavy Punch"};
	int monsterAttackDamage[3] = {10, 15, 50};
		levelMonster.monsterHealth = 200 + LvlCount * 1.5;


	
// -----------------MAKING ATTACKS---------------------\\
	cout << "HP: " << player.health;
	cout << "Monsters: " << levelMonster.monsterCount;
	cout << "Monster HP: " << levelMonster.monsterHealth;
	cout << "\n\n Monster type: " << levelMonster.monsterType;
	cout << "\n\n\nMAGIC ATTACKS\n";
	cout << "\n\n (1) " << playerAttacks.attack1 << " DMG-" << playerAttacks.damageAttack1 << "     Mana-" << playerAttacks.manaAttack1;
	cout << "\n\n (2) " << playerAttacks.attack2 << " DMG-" << playerAttacks.damageAttack2 << "     Mana-" << playerAttacks.manaAttack2;
	cout << "\n\n (3) " << playerAttacks.attack3 << " DMG-" << playerAttacks.damageAttack3 << "     Mana-" << playerAttacks.manaAttack3;
	cout << "\n\n (4) " << playerAttacks.attack4 << " DMG-" << playerAttacks.damageAttack4 << "     Mana-" << playerAttacks.manaAttack4;
	cout << "\n\n\nMELEE ATTACKS\n";
	cout << "\n\n (5) " << playerAttacks.attack5 << " DMG-" << playerAttacks.damageAttack5 << "     Mana-" << playerAttacks.manaAttack5;
	cout << "\n\n (6) " << playerAttacks.attack6 << " DMG-" << playerAttacks.damageAttack6 << "     Mana-" << playerAttacks.manaAttack6;
	cout << "\n\n (7) " << playerAttacks.attack7 << " DMG-" << playerAttacks.damageAttack7 << "     Mana-" << playerAttacks.manaAttack7;
	cout << "\n\n (8) Inventory";
	cout << "\n > ";
	
	// While loop

	while((levelMonster.monsterCount = 1)){
	cin >> playerAttack;
	// Attack 1 Loop
	if(playerAttack == 1){
		ClearScreen();
		levelMonster.monsterHealth = levelMonster.monsterHealth - playerAttacks.damageAttack1;
		int RandAtk = rand() % 3;
		int RandDmg = rand() % 3;
		player.mana -= playerAttacks.manaAttack1;
		cout << endl <<endl<< levelMonster.monsterType << " used " << monsterAttack[RandAtk] << " and dealt " << monsterAttackDamage[RandDmg] << endl;
		player.health = player.health - monsterAttackDamage[RandDmg];
	
			cout << "\nHP: " << player.health << endl;
			cout << "\nMana: " << player.mana << endl;
			cout << "\nMonsters: " << levelMonster.monsterCount << endl;
			cout << "Monster health: " << levelMonster.monsterHealth << endl;
	cout << "\n\n Monster type: " << levelMonster.monsterType;
	cout << "\n\n\nMAGIC ATTACKS\n";
	cout << "\n\n (1) " << playerAttacks.attack1 << " DMG-" << playerAttacks.damageAttack1 << "     Mana-" << playerAttacks.manaAttack1;
	cout << "\n\n (2) " << playerAttacks.attack2 << " DMG-" << playerAttacks.damageAttack2 << "     Mana-" << playerAttacks.manaAttack2;
	cout << "\n\n (3) " << playerAttacks.attack3 << " DMG-" << playerAttacks.damageAttack3 << "     Mana-" << playerAttacks.manaAttack3;
	cout << "\n\n (4) " << playerAttacks.attack4 << " DMG-" << playerAttacks.damageAttack4 << "     Mana-" << playerAttacks.manaAttack4;
	cout << "\n\n\nMELEE ATTACKS\n";
	cout << "\n\n (5) " << playerAttacks.attack5 << " DMG-" << playerAttacks.damageAttack5 << "     Mana-" << playerAttacks.manaAttack5;
	cout << "\n\n (6) " << playerAttacks.attack6 << " DMG-" << playerAttacks.damageAttack6 << "     Mana-" << playerAttacks.manaAttack6;
	cout << "\n\n (7) " << playerAttacks.attack7 << " DMG-" << playerAttacks.damageAttack7 << "     Mana-" << playerAttacks.manaAttack7;
	cout << "\n\n (8) Inventory";
	cout << "\n > ";

	if(player.mana < playerAttacks.manaAttack1){
		cout << "Not enough Mana!\n > ";
	}

	}

	// Attack 2 loop
	if(playerAttack == 2){
		ClearScreen();
		int RandAtk = rand() % 3;
		int RandDmg = rand() % 3;
		player.mana -= playerAttacks.manaAttack2;
		cout << endl <<endl<< levelMonster.monsterType << " used " << monsterAttack[RandAtk] << " and dealt " << monsterAttackDamage[RandDmg] << endl;
		levelMonster.monsterHealth = levelMonster.monsterHealth - playerAttacks.damageAttack2;
		cout << "HP: " << player.health << endl;
		cout << "\nMana: " << player.mana << endl;
			cout << "Monsters: " << levelMonster.monsterCount << endl;
			cout << "Monster health: " << levelMonster.monsterHealth;
	cout << "\n\n Monster type: " << levelMonster.monsterType;
	cout << "\n\n\nMAGIC ATTACKS\n";
	cout << "\n\n (1) " << playerAttacks.attack1 << " DMG-" << playerAttacks.damageAttack1 << "     Mana-" << playerAttacks.manaAttack1;
	cout << "\n\n (2) " << playerAttacks.attack2 << " DMG-" << playerAttacks.damageAttack2 << "     Mana-" << playerAttacks.manaAttack2;
	cout << "\n\n (3) " << playerAttacks.attack3 << " DMG-" << playerAttacks.damageAttack3 << "     Mana-" << playerAttacks.manaAttack3;
	cout << "\n\n (4) " << playerAttacks.attack4 << " DMG-" << playerAttacks.damageAttack4 << "     Mana-" << playerAttacks.manaAttack4;
	cout << "\n\n\nMELEE ATTACKS\n";
	cout << "\n\n (5) " << playerAttacks.attack5 << " DMG-" << playerAttacks.damageAttack5 << "     Mana-" << playerAttacks.manaAttack5;
	cout << "\n\n (6) " << playerAttacks.attack6 << " DMG-" << playerAttacks.damageAttack6 << "     Mana-" << playerAttacks.manaAttack6;
	cout << "\n\n (7) " << playerAttacks.attack7 << " DMG-" << playerAttacks.damageAttack7 << "     Mana-" << playerAttacks.manaAttack7;
	cout << "\n\n (8) Inventory";
	cout << "\n > ";
		if(player.mana < playerAttacks.manaAttack2){
		cout << "Not enough Mana!\n > ";
	}
	}

	// Attack 3 loop

	if(playerAttack == 3){
		ClearScreen();
		int RandAtk = rand() % 3;
		int RandDmg = rand() % 3;
		player.mana -= playerAttacks.manaAttack3;
				cout << endl <<endl<< levelMonster.monsterType << " used " << monsterAttack[RandAtk] << " and dealt " << monsterAttackDamage[RandDmg] << endl;
		levelMonster.monsterHealth = levelMonster.monsterHealth - playerAttacks.damageAttack3;
		cout << "\nHP: " << player.health << endl;
		cout << "\nMana: " << player.mana << endl;
			cout << "Monsters: " << levelMonster.monsterCount << endl;
			cout << "Monster health: " << levelMonster.monsterHealth;
	cout << "\n\n Monster type: " << levelMonster.monsterType;
	cout << "\n\n\nMAGIC ATTACKS\n";
	cout << "\n\n (1) " << playerAttacks.attack1 << " DMG-" << playerAttacks.damageAttack1 << "     Mana-" << playerAttacks.manaAttack1;
	cout << "\n\n (2) " << playerAttacks.attack2 << " DMG-" << playerAttacks.damageAttack2 << "     Mana-" << playerAttacks.manaAttack2;
	cout << "\n\n (3) " << playerAttacks.attack3 << " DMG-" << playerAttacks.damageAttack3 << "     Mana-" << playerAttacks.manaAttack3;
	cout << "\n\n (4) " << playerAttacks.attack4 << " DMG-" << playerAttacks.damageAttack4 << "     Mana-" << playerAttacks.manaAttack4;
	cout << "\n\n\nMELEE ATTACKS\n";
	cout << "\n\n (5) " << playerAttacks.attack5 << " DMG-" << playerAttacks.damageAttack5 << "     Mana-" << playerAttacks.manaAttack5;
	cout << "\n\n (6) " << playerAttacks.attack6 << " DMG-" << playerAttacks.damageAttack6 << "     Mana-" << playerAttacks.manaAttack6;
	cout << "\n\n (7) " << playerAttacks.attack7 << " DMG-" << playerAttacks.damageAttack7 << "     Mana-" << playerAttacks.manaAttack7;
	cout << "\n\n (8) Inventory";
	cout << "\n > ";
		if(player.mana < playerAttacks.manaAttack3){
		cout << "Not enough Mana!\n > ";
	}
	}

	// Attack 4 loop
	if(playerAttack == 4){
		ClearScreen();
		// Random monster attacks
		int RandAtk = rand() % 3;
		int RandDmg = rand() % 3;
		player.mana -= playerAttacks.manaAttack4;
				player.health -= monsterAttackDamage[RandDmg];
  levelMonster.monsterHealth = levelMonster.monsterHealth - playerAttacks.damageAttack4;
	cout << endl << endl<< levelMonster.monsterType << " used " << monsterAttack[RandAtk] << " and dealt " << monsterAttackDamage[RandDmg] << endl;
	cout << "HP: " << player.health << endl;
	cout << "\nMana: " << player.mana << endl;
	cout << "Monsters: " << levelMonster.monsterCount << endl;
	cout << "Monster health: " << levelMonster.monsterHealth;
	cout << "\n\n Monster type: " << levelMonster.monsterType;
	cout << "\n\n\nMAGIC ATTACKS\n";
	cout << "\n\n (1) " << playerAttacks.attack1 << " DMG-" << playerAttacks.damageAttack1 << "     Mana-" << playerAttacks.manaAttack1;
	cout << "\n\n (2) " << playerAttacks.attack2 << " DMG-" << playerAttacks.damageAttack2 << "     Mana-" << playerAttacks.manaAttack2;
	cout << "\n\n (3) " << playerAttacks.attack3 << " DMG-" << playerAttacks.damageAttack3 << "     Mana-" << playerAttacks.manaAttack3;
	cout << "\n\n (4) " << playerAttacks.attack4 << " DMG-" << playerAttacks.damageAttack4 << "     Mana-" << playerAttacks.manaAttack4;
	cout << "\n\n\nMELEE ATTACKS\n";
	cout << "\n\n (5) " << playerAttacks.attack5 << " DMG-" << playerAttacks.damageAttack5 << "     Mana-" << playerAttacks.manaAttack5;
	cout << "\n\n (6) " << playerAttacks.attack6 << " DMG-" << playerAttacks.damageAttack6 << "     Mana-" << playerAttacks.manaAttack6;
	cout << "\n\n (7) " << playerAttacks.attack7 << " DMG-" << playerAttacks.damageAttack7 << "     Mana-" << playerAttacks.manaAttack7;
	cout << "\n\n (8) Inventory";
	cout << "\n > ";
		if(player.mana < playerAttacks.manaAttack4){
		cout << "Not enough Mana!\n > ";
	}
	}

	// Attack 5 loop
	if(playerAttack == 5){
		ClearScreen();
		// Random monster attacks
		int RandAtk = rand() % 3;
		int RandDmg = rand() % 3;
		player.mana -= playerAttacks.manaAttack5;
		player.mana += 9;
				player.health = player.health - monsterAttackDamage[RandDmg];
  levelMonster.monsterHealth = levelMonster.monsterHealth - playerAttacks.damageAttack5;
	cout << endl << endl << levelMonster.monsterType << " used " << monsterAttack[RandAtk] << " and dealt " << monsterAttackDamage[RandDmg] << endl;
	cout << "HP: " << player.health << endl;
	cout << "\nMana: " << player.mana << endl;
	cout << "Monsters: " << levelMonster.monsterCount << endl;
	cout << "Monster health: " << levelMonster.monsterHealth;
	cout << "\n\n Monster type: " << levelMonster.monsterType;
	cout << "\n\n\nMAGIC ATTACKS\n";
	cout << "\n\n (1) " << playerAttacks.attack1 << " DMG-" << playerAttacks.damageAttack1 << "     Mana-" << playerAttacks.manaAttack1;
	cout << "\n\n (2) " << playerAttacks.attack2 << " DMG-" << playerAttacks.damageAttack2 << "     Mana-" << playerAttacks.manaAttack2;
	cout << "\n\n (3) " << playerAttacks.attack3 << " DMG-" << playerAttacks.damageAttack3 << "     Mana-" << playerAttacks.manaAttack3;
	cout << "\n\n (4) " << playerAttacks.attack4 << " DMG-" << playerAttacks.damageAttack4 << "     Mana-" << playerAttacks.manaAttack4;
	cout << "\n\n\nMELEE ATTACKS\n";
	cout << "\n\n (5) " << playerAttacks.attack5 << " DMG-" << playerAttacks.damageAttack5 << "     Mana-" << playerAttacks.manaAttack5;
	cout << "\n\n (6) " << playerAttacks.attack6 << " DMG-" << playerAttacks.damageAttack6 << "     Mana-" << playerAttacks.manaAttack6;
	cout << "\n\n (7) " << playerAttacks.attack7 << " DMG-" << playerAttacks.damageAttack7 << "     Mana-" << playerAttacks.manaAttack7;
	cout << "\n\n (8) Inventory";
	cout << "\n > ";
		if(player.mana < playerAttacks.manaAttack5){
		cout << "Not enough Mana!\n > ";
	}
	}
		if(playerAttack == 6){
			ClearScreen();
		levelMonster.monsterHealth = levelMonster.monsterHealth - playerAttacks.damageAttack6;
		int RandAtk = rand() % 3;
		int RandDmg = rand() % 3;
		player.mana -= playerAttacks.manaAttack6;
		cout << endl << levelMonster.monsterType << " used " << monsterAttack[RandAtk] << " and dealt " << monsterAttackDamage[RandDmg] << endl;
		player.health = player.health - monsterAttackDamage[RandDmg];
	
			cout << "\nHP: " << player.health << endl;
			cout << "\nMana: " << player.mana << endl;
			cout << "\nMonsters: " << levelMonster.monsterCount << endl;
			cout << "Monster health: " << levelMonster.monsterHealth << endl;
	cout << "\n\n Monster type: " << levelMonster.monsterType;
	cout << "\n\n\nMAGIC ATTACKS\n";
	cout << "\n\n (1) " << playerAttacks.attack1 << " DMG-" << playerAttacks.damageAttack1 << "     Mana-" << playerAttacks.manaAttack1;
	cout << "\n\n (2) " << playerAttacks.attack2 << " DMG-" << playerAttacks.damageAttack2 << "     Mana-" << playerAttacks.manaAttack2;
	cout << "\n\n (3) " << playerAttacks.attack3 << " DMG-" << playerAttacks.damageAttack3 << "     Mana-" << playerAttacks.manaAttack3;
	cout << "\n\n (4) " << playerAttacks.attack4 << " DMG-" << playerAttacks.damageAttack4 << "     Mana-" << playerAttacks.manaAttack4;
	cout << "\n\n\nMELEE ATTACKS\n";
	cout << "\n\n (5) " << playerAttacks.attack5 << " DMG-" << playerAttacks.damageAttack5 << "     Mana-" << playerAttacks.manaAttack5;
	cout << "\n\n (6) " << playerAttacks.attack6 << " DMG-" << playerAttacks.damageAttack6 << "     Mana-" << playerAttacks.manaAttack6;
	cout << "\n\n (7) " << playerAttacks.attack7 << " DMG-" << playerAttacks.damageAttack7 << "     Mana-" << playerAttacks.manaAttack7;
	cout << "\n\n (8) Inventory";
	cout << "\n > ";

	if(player.mana < playerAttacks.manaAttack6){
		cout << "Not enough Mana!\n > ";
	}

	}

	if(playerAttack == 7){
		ClearScreen();
		levelMonster.monsterHealth = levelMonster.monsterHealth - playerAttacks.damageAttack7;
		int RandAtk = rand() % 3;
		int RandDmg = rand() % 3;
		player.mana -= playerAttacks.manaAttack7;
		cout <<  endl << endl << levelMonster.monsterType << " used " << monsterAttack[RandAtk] << " and dealt " << monsterAttackDamage[RandDmg] << endl;
		player.health = player.health - monsterAttackDamage[RandDmg];
	
			cout << "\nHP: " << player.health << endl;
			cout << "\nMana: " << player.mana << endl;
			cout << "\nMonsters: " << levelMonster.monsterCount << endl;
			cout << "Monster health: " << levelMonster.monsterHealth << endl;
	cout << "\n\n Monster type: " << levelMonster.monsterType;
	cout << "\n\n\nMAGIC ATTACKS\n";
	cout << "\n\n (1) " << playerAttacks.attack1 << " DMG-" << playerAttacks.damageAttack1 << "     Mana-" << playerAttacks.manaAttack1;
	cout << "\n\n (2) " << playerAttacks.attack2 << " DMG-" << playerAttacks.damageAttack2 << "     Mana-" << playerAttacks.manaAttack2;
	cout << "\n\n (3) " << playerAttacks.attack3 << " DMG-" << playerAttacks.damageAttack3 << "     Mana-" << playerAttacks.manaAttack3;
	cout << "\n\n (4) " << playerAttacks.attack4 << " DMG-" << playerAttacks.damageAttack4 << "     Mana-" << playerAttacks.manaAttack4;
	cout << "\n\n\nMELEE ATTACKS\n";
	cout << "\n\n (5) " << playerAttacks.attack5 << " DMG-" << playerAttacks.damageAttack5 << "     Mana-" << playerAttacks.manaAttack5;
	cout << "\n\n (6) " << playerAttacks.attack6 << " DMG-" << playerAttacks.damageAttack6 << "     Mana-" << playerAttacks.manaAttack6;
	cout << "\n\n (7) " << playerAttacks.attack7 << " DMG-" << playerAttacks.damageAttack7 << "     Mana-" << playerAttacks.manaAttack7;
	cout << "\n\n (8) Inventory";
	cout << "\n > ";

	if(player.mana < playerAttacks.manaAttack7){
		cout << "Not enough Mana!\n > ";
	}

	}

	// When player uses Inventory
	if(playerAttack == 8){
		ClearScreen();
		cout << "\n\n\n\n---Inventory---\n\n\n\n\n";
		cout << "(1) Item 1 " << playerInv.purchasedItem1 << " HP+ " << playerInv.HP1;
		cout << "\n\n(2) Item 2 " << playerInv.purchasedItem2 << " HP+ " << playerInv.HP2;
		cout << "\n\n(3) Item 3 " << playerInv.purchesedItem3 << " HP+ " << playerInv.HP3;
		cout << "\n\n(4) Power Up " << playerInv.PowerUp << "HP+ " << playerInv.HP4;
		cout << "\n Small potion count - " << playerInv.item1cnt << "\n Medium potion count - " << playerInv.item2cnt << "\n Large potion count - " << playerInv.item3cnt;
		cout << "\n\n(5) Back to battle";
		cout << "\n > ";
		cin >> playerAttack;
		if(playerAttack == 1){
			ClearScreen();
			player.health += playerInv.HP1;
	cout << "(1) Item 1 " << playerInv.purchasedItem1 << " HP+ " << playerInv.HP1;
		cout << "\n\n(2) Item 2 " << playerInv.purchasedItem2 << " HP+ " << playerInv.HP2;
		cout << "\n\n(3) Item 3 " << playerInv.purchesedItem3 << " HP+ " << playerInv.HP3;
		cout << "\n\n(4) Power Up " << playerInv.PowerUp << "HP+ " << playerInv.HP4;
		cout << "\n Small potion count - " << playerInv.item1cnt << "\n Medium potion count - " << playerInv.item2cnt << "\n Large potion count - " << playerInv.item3cnt;
		cout << "\n\n(5) Back to battle";
		cout << "\n > ";
		}
				if(playerAttack == 2){
					ClearScreen();
			player.health += playerInv.HP2;
		cout << "(1) Item 1 " << playerInv.purchasedItem1 << " HP+ " << playerInv.HP1;
		cout << "\n\n(2) Item 2 " << playerInv.purchasedItem2 << " HP+ " << playerInv.HP2;
		cout << "\n\n(3) Item 3 " << playerInv.purchesedItem3 << " HP+ " << playerInv.HP3;
		cout << "\n\n(4) Power Up " << playerInv.PowerUp << "HP+ " << playerInv.HP4;
		cout << "\n Small potion count - " << playerInv.item1cnt << "\n Medium potion count - " << playerInv.item2cnt << "\n Large potion count - " << playerInv.item3cnt;
		cout << "\n\n(5) Back to battle";
		cout << "\n > ";
		}
				if(playerAttack == 3){
					ClearScreen();
			player.health += playerInv.HP3;
	cout << "(1) Item 1 " << playerInv.purchasedItem1 << " HP+ " << playerInv.HP1;
		cout << "\n\n(2) Item 2 " << playerInv.purchasedItem2 << " HP+ " << playerInv.HP2;
		cout << "\n\n(3) Item 3 " << playerInv.purchesedItem3 << " HP+ " << playerInv.HP3;
		cout << "\n\n(4) Power Up " << playerInv.PowerUp << "HP+ " << playerInv.HP4;
		cout << "\n Small potion count - " << playerInv.item1cnt << "\n Medium potion count - " << playerInv.item2cnt << "\n Large potion count - " << playerInv.item3cnt;
		cout << "\n\n(5) Back to battle";
		cout << "\n > ";
		}
		if(playerAttack == 4){
			ClearScreen();
			if(PwrUpCnt < 0){
				cout << "Out of power ups!\n\n";
					cout << "(1) Item 1 " << playerInv.purchasedItem1 << " HP+ " << playerInv.HP1;
		cout << "\n\n(2) Item 2 " << playerInv.purchasedItem2 << " HP+ " << playerInv.HP2;
		cout << "\n\n(3) Item 3 " << playerInv.purchesedItem3 << " HP+ " << playerInv.HP3;
		cout << "\n\n(4) Power Up " << playerInv.PowerUp << "HP+ " << playerInv.HP4;
		cout << "\n Small potion count - " << playerInv.item1cnt << "\n Medium potion count - " << playerInv.item2cnt << "\n Large potion count - " << playerInv.item3cnt;
		cout << "\n\n(5) Back to battle";
		cout << "\n > ";
			}
			cout << "POWER UP ACTIVATED!\n";
			player.health += playerInv.HP4;
			player.mana += 200;
			PwrUpCnt -= 1;

			playerAttacks.attack1 = "Fire Punches";
	playerAttacks.attack2 = "Fire Walker";
	playerAttacks.attack3 = "Fire collumn";
	playerAttacks.attack4 = "Fire Beam";
 playerAttacks.attack5 = "Heavy Forearm Slash";
 playerAttacks.attack6 = "Air Slash";
 playerAttacks.attack7="Cosmic stab barrage";

 	playerAttacks.damageAttack1 = 20;
	playerAttacks.damageAttack2 = 35;
	playerAttacks.damageAttack3 = 40;
	playerAttacks.damageAttack4 = 50;
	playerAttacks.damageAttack5 = 10;
	playerAttacks.damageAttack6=20;
	playerAttacks.damageAttack7=35;
	// Mana
	playerAttacks.manaAttack1 = 20;
	playerAttacks.manaAttack2 = 35;
	playerAttacks.manaAttack3 = 45;
	playerAttacks.manaAttack4 = 50;
	playerAttacks.manaAttack5 = 0;
	playerAttacks.manaAttack6=0;
	playerAttacks.manaAttack7=0;

				cout << "(1) Item 1 " << playerInv.purchasedItem1 << " HP+ " << playerInv.HP1;
		cout << "\n\n(2) Item 2 " << playerInv.purchasedItem2 << " HP+ " << playerInv.HP2;
		cout << "\n\n(3) Item 3 " << playerInv.purchesedItem3 << " HP+ " << playerInv.HP3;
		cout << "\n\n(4) Power Up " << playerInv.PowerUp << "HP+ " << playerInv.HP4;
		cout << "\n Small potion count - " << playerInv.item1cnt << "\n Medium potion count - " << playerInv.item2cnt << "\n Large potion count - " << playerInv.item3cnt;
		cout << "\n\n(5) Back to battle";
		cout << "\n > ";
		}
				if(playerAttack == 5){
					ClearScreen();
				cout << "\nHP: " << player.health;
	cout << "Monsters: " << levelMonster.monsterCount;
	cout << "Monster HP: " << levelMonster.monsterHealth;
	cout << "\n\n Monster type: " << levelMonster.monsterType;
	cout << "\n\n\nMAGIC ATTACKS\n";
	cout << "\n\n (1) " << playerAttacks.attack1 << " DMG-" << playerAttacks.damageAttack1 << "     Mana-" << playerAttacks.manaAttack1;
	cout << "\n\n (2) " << playerAttacks.attack2 << " DMG-" << playerAttacks.damageAttack2 << "     Mana-" << playerAttacks.manaAttack2;
	cout << "\n\n (3) " << playerAttacks.attack3 << " DMG-" << playerAttacks.damageAttack3 << "     Mana-" << playerAttacks.manaAttack3;
	cout << "\n\n (4) " << playerAttacks.attack4 << " DMG-" << playerAttacks.damageAttack4 << "     Mana-" << playerAttacks.manaAttack4;
	cout << "\n\n\nMELEE ATTACKS\n";
	cout << "\n\n (5) " << playerAttacks.attack5 << " DMG-" << playerAttacks.damageAttack5 << "     Mana-" << playerAttacks.manaAttack5;
	cout << "\n\n (6) " << playerAttacks.attack6 << " DMG-" << playerAttacks.damageAttack6 << "     Mana-" << playerAttacks.manaAttack6;
	cout << "\n\n (7) " << playerAttacks.attack7 << " DMG-" << playerAttacks.damageAttack7 << "     Mana-" << playerAttacks.manaAttack7;
	cout << "\n\n (8) Inventory";
	cout << "\n > ";
			
		}

	}

	// When player wins
if(levelMonster.monsterHealth <= 0){
	ClearScreen();
		XP = LvlWin(XP);
		
		GameMenu();
	}
	else if(player.health <= 0){
		cout << "You died!\n";
		GameMenu();
	}

}

}






/*
Game menu includes options for the player to choose to play the game
*/

void GameMenu(int coins){

	struct Attacks sword;
	struct Hero player;
	string gameMenuChoice;


		
		fstream stats;
		stats.open("stats.dat", ios::out);
string ascii =
"██╗░░░░░███████╗░██████╗░███████╗███╗░░██╗██████╗░\n"
"██║░░░░░██╔════╝██╔════╝░██╔════╝████╗░██║██╔══██╗\n"
"██║░░░░░█████╗░░██║░░██╗░█████╗░░██╔██╗██║██║░░██║\n"
"██║░░░░░██╔══╝░░██║░░╚██╗██╔══╝░░██║╚████║██║░░██║\n"
"███████╗███████╗╚██████╔╝███████╗██║░╚███║██████╔╝\n"
"╚══════╝╚══════╝░╚═════╝░╚══════╝╚═╝░░╚══╝╚═════╝░\n";

	cout << "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n";
	cout << ascii;
	
	Lvl = LvlUp(XP, Lvl);
	stats << "\nXP: " << XP << endl;
	stats << "Level: " << Lvl << endl;
	cout << "Coins: " << coins << endl;
	cout << "XP: " << XP << endl;
	cout << "Level: " << Lvl << endl;
	cout << "(a) Play Level\n";
	cout << "(b) Shop\n";
	cout << "(c) Exit\n";
	cin >> gameMenuChoice;
	if(gameMenuChoice == "a"){
		ClearScreen();
		LevelStart(XP, Lvl);
	}
	if(gameMenuChoice == "b"){
		ClearScreen();
		Shop(coins);
	}
	if(gameMenuChoice == "c"){
		sleep(1);
		ClearScreen();
		cout << "Game EXITED\n";
		Menu();
	}

}


void Login(){
	string loginChoice;
	string username;
	string password;
	fstream login;
	login.open("login.dat", ios::out);
	cout << 
"██╗░░░░░░█████╗░░██████╗░██╗███╗░░██╗  ██╗\n"
"██║░░░░░██╔══██╗██╔════╝░██║████╗░██║  ╚═╝\n"
"██║░░░░░██║░░██║██║░░██╗░██║██╔██╗██║  ░░░\n"
"██║░░░░░██║░░██║██║░░╚██╗██║██║╚████║  ░░░\n"
"███████╗╚█████╔╝╚██████╔╝██║██║░╚███║  ██╗\n"
"╚══════╝░╚════╝░░╚═════╝░╚═╝╚═╝░░╚══╝  ╚═╝\n";
	cout << "\n\n\n\n\n\n\nUsername\n";
	cout << "\n > ";
	cin >> username;
	login << "username: " << username << endl;
	cout << "\n\n\n Password\n";
	cout << "\n > ";
	cin >> password;
	login << "Pass: " << password;
	login.close();
	cout << "loading...\n\n\n";
	cout << "(a) Start\n";
	cin >> loginChoice;
	
	if((loginChoice == "a") || (loginChoice == "A")){
		
		GameMenu();
	}
}

// StoryMode

void StoryMode(void){
	int storyModeChoice;
	cout << "\n\n\n\n\n\n\n\n\n\n\n\n\n-----------------Welcome to story mode!----------------\n\n";
	cout << "(1) Login\n";
	cin >> storyModeChoice;
	if(storyModeChoice == 1){
		sleep(1);
		ClearScreen();
		Login();
	}
}

// Credits
		void Credits(){
	
	int creditsChoice;
	cout << "\n\n\n\n\nCreator: Skyy Civil\n\n";
	cout << "(1) 	Back to menu\n";
	cout << "(2) 	Continue to story mode\n";
	cin >> creditsChoice;
	if(creditsChoice == 1){
		sleep(1);
		ClearScreen();
		Menu();
	}
	if (creditsChoice == 2){
		sleep(1);
		ClearScreen();
		StoryMode();
	}
}

// Main Menu

void Menu(){
	string menuChoice;
	int ui= 0;
	while(ui == 0){
	cout << 
"███╗░░░███╗░█████╗░██████╗░███████╗  ░██████╗███████╗██╗░░░░░███████╗░█████╗░████████╗\n"
"████╗░████║██╔══██╗██╔══██╗██╔════╝  ██╔════╝██╔════╝██║░░░░░██╔════╝██╔══██╗╚══██╔══╝\n"
"██╔████╔██║██║░░██║██║░░██║█████╗░░  ╚█████╗░█████╗░░██║░░░░░█████╗░░██║░░╚═╝░░░██║░░░\n"
"██║╚██╔╝██║██║░░██║██║░░██║██╔══╝░░  ░╚═══██╗██╔══╝░░██║░░░░░██╔══╝░░██║░░██╗░░░██║░░░\n"
"██║░╚═╝░██║╚█████╔╝██████╔╝███████╗  ██████╔╝███████╗███████╗███████╗╚█████╔╝░░░██║░░░\n"
"╚═╝░░░░░╚═╝░╚════╝░╚═════╝░╚══════╝  ╚═════╝░╚══════╝╚══════╝╚══════╝░╚════╝░░░░╚═╝░░░\n";
	cout << "(a) Story Mode\n";
	cout << "(b) Credits\n";
	cin >> menuChoice;
	if((menuChoice == "a") || (menuChoice == "A")){
		sleep(1);
		ClearScreen();
		StoryMode();
	}
	if((menuChoice == "b") || (menuChoice == "B")){
		sleep(1);
		ClearScreen();
		Credits();
	}

	}
};

// ------------MAIN--------------- \\

int main()
{
	srand (time(NULL));
	cout << "Loading...";
	sleep(2);
	cout << "Starting!";
	sleep(1);
	ClearScreen(); // Clear screen to avoid any issues
	Menu(); // run Menu functions
	
}